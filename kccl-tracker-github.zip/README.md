# KCCL Tracker

Single-file dashboard (`index.html`) for the KCCL requirements sheet: Dashboard, List, Masters, Connect Google Sheet, themes.
Data lives in your Google Sheet. This repository holds only the page.

## Publish with GitHub Pages
1. Create a new repository and upload `index.html` (keep this exact name), `.nojekyll` and `README.md`.
2. Settings > Pages > Source: **Deploy from a branch**, Branch: **main**, folder **/ (root)** > Save.
3. After a minute the site is at `https://<your-username>.github.io/<repo-name>/`.

## Connect to the sheet (once per browser)
1. Open the site > **Connect Google Sheet**.
2. Paste your Apps Script link ending `/exec?key=YOUR_KEY` > **Sync now**.
3. The link is stored only in that browser. It is **not** in this repository.

## Security
- Do not put the Apps Script link or key in `index.html` or anywhere in the repository. A public site exposes its source and the key lets anyone read and edit the sheet.
- Keep the Google Sheet's general access **Restricted**. The Apps Script runs as you and needs no sharing.
- To rotate access: change `KEY` in Code.gs, deploy a new version, and use the new link.

## Updating
Upload a new `index.html` with the same name and commit. Data is unaffected.
